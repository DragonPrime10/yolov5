# person > 2023-12-04 3:10pm
https://universe.roboflow.com/oklahoma-state-university-rcgwk/person-469rx

Provided by a Roboflow user
License: CC BY 4.0

